./gradlew test
